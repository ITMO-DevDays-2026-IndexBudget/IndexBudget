-- IndexBudget recommendations; not executed automatically.
-- run_id: ec809a87-c4d6-4d92-87c5-bc6c8781d864
-- input_hash: 9e0705f4bd3dfe67e8dbad1291da60859ba50170f75d71e38e4dc12bc565bf55
-- index_methods: btree
-- selected_objective: robust

CREATE INDEX "ib_36da7cec779c6aee92f3b033327105fe3f7a25db36973024606043b7b1f6" ON "public"."records" USING btree ("group_id" "pg_catalog"."int4_ops" ASC NULLS LAST, "value" "pg_catalog"."int4_ops" ASC NULLS LAST) INCLUDE ("id");
CREATE INDEX "ib_6b42a62519609891a2964994b65f43644d345af6b165e1220092a348dbb0" ON "public"."records" USING btree ("value" "pg_catalog"."int4_ops" ASC NULLS LAST);
