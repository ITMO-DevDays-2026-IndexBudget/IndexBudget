-- IndexBudget recommendations; not executed automatically.
-- run_id: 33febe44-0656-43a4-8323-e9c3bc9a1d13
-- input_hash: 9e0705f4bd3dfe67e8dbad1291da60859ba50170f75d71e38e4dc12bc565bf55
-- index_methods: btree
-- selected_objective: robust

CREATE INDEX "ib_5d770c036759e8cb1b45d974e372dea64ca5606fe78c1eacaeb76fc54080" ON "public"."groups" USING btree ("category" "pg_catalog"."int4_ops" ASC NULLS LAST);
