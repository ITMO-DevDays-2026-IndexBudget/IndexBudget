-- IndexBudget recommendations; not executed automatically.
-- run_id: d6156e3e-ebd0-48b9-8626-5e1272e36e92
-- input_hash: 9e0705f4bd3dfe67e8dbad1291da60859ba50170f75d71e38e4dc12bc565bf55
-- index_methods: btree
-- selected_objective: robust

