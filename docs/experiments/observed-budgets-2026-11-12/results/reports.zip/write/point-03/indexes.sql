-- IndexBudget recommendations; not executed automatically.
-- run_id: ba0b84a5-d53c-4ded-9f4d-95752236a19c
-- input_hash: b6b4865e5808bf1bbde2f2b140917609b311a0d7f19be511bcbad315236763e6
-- index_methods: btree
-- selected_objective: robust

CREATE INDEX "ib_03dfa4d6f086896e7252ee7c3baf17c8b3c4e1770b4e7183c1eac7462f33" ON "public"."records" USING btree ("created_at" "pg_catalog"."timestamp_ops" ASC NULLS LAST);
CREATE INDEX "ib_6b42a62519609891a2964994b65f43644d345af6b165e1220092a348dbb0" ON "public"."records" USING btree ("value" "pg_catalog"."int4_ops" ASC NULLS LAST);
CREATE INDEX "ib_d2e9c41347f8a774adc74bf3ab4476011ac9fdab397101eb77db9c50f8d3" ON "public"."records" USING btree ("group_id" "pg_catalog"."int4_ops" ASC NULLS LAST);
