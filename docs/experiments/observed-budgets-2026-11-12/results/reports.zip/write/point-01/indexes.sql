-- IndexBudget recommendations; not executed automatically.
-- run_id: bff28082-4a09-4af0-8e24-dd4304754ce4
-- input_hash: b6b4865e5808bf1bbde2f2b140917609b311a0d7f19be511bcbad315236763e6
-- index_methods: btree
-- selected_objective: robust

