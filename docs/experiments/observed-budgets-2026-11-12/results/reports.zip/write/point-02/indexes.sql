-- IndexBudget recommendations; not executed automatically.
-- run_id: 8d878fee-3db7-4a87-ae9f-144093bfa151
-- input_hash: b6b4865e5808bf1bbde2f2b140917609b311a0d7f19be511bcbad315236763e6
-- index_methods: btree
-- selected_objective: robust

CREATE INDEX "ib_d2e9c41347f8a774adc74bf3ab4476011ac9fdab397101eb77db9c50f8d3" ON "public"."records" USING btree ("group_id" "pg_catalog"."int4_ops" ASC NULLS LAST);
