-- IndexBudget recommendations; not executed automatically.
-- run_id: 5289136e-8a87-4daa-b93b-38040126ac1f
-- input_hash: b6b4865e5808bf1bbde2f2b140917609b311a0d7f19be511bcbad315236763e6
-- index_methods: btree
-- selected_objective: robust

CREATE INDEX "ib_13506513486f8f4f9dba27e45cf56d3f5baaca8ae99a2588288fcfb4a9f8" ON "public"."records" USING btree ("group_id" "pg_catalog"."int4_ops" ASC NULLS LAST, "value" "pg_catalog"."int4_ops" ASC NULLS LAST);
CREATE INDEX "ib_1f49313917f0cb8f6e95d7235bbe9373111322427785df823b321729583b" ON "public"."records" USING btree ("group_id" "pg_catalog"."int4_ops" ASC NULLS LAST, "created_at" "pg_catalog"."timestamp_ops" ASC NULLS LAST);
CREATE INDEX "ib_2c5f7c856896b0bbae62e7607ea9cf82283cb814cf22c3963e195204eb78" ON "public"."records" USING btree ("created_at" "pg_catalog"."timestamp_ops" ASC NULLS LAST) INCLUDE ("id", "value");
CREATE INDEX "ib_36da7cec779c6aee92f3b033327105fe3f7a25db36973024606043b7b1f6" ON "public"."records" USING btree ("group_id" "pg_catalog"."int4_ops" ASC NULLS LAST, "value" "pg_catalog"."int4_ops" ASC NULLS LAST) INCLUDE ("id");
CREATE INDEX "ib_760a8e60a44aa6a3d21a6f661ca9012e38965a49d5024d8215515891630f" ON "public"."records" USING btree ("value" "pg_catalog"."int4_ops" ASC NULLS LAST) INCLUDE ("id", "payload");
