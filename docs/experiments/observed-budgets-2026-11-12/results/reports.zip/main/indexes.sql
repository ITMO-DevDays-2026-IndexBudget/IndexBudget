-- IndexBudget recommendations; not executed automatically.
-- run_id: 813d138b-ae27-41e0-ab32-16b2e1fbd9fb
-- input_hash: 9e0705f4bd3dfe67e8dbad1291da60859ba50170f75d71e38e4dc12bc565bf55
-- index_methods: btree
-- selected_objective: robust

CREATE INDEX "ib_36da7cec779c6aee92f3b033327105fe3f7a25db36973024606043b7b1f6" ON "public"."records" USING btree ("group_id" "pg_catalog"."int4_ops" ASC NULLS LAST, "value" "pg_catalog"."int4_ops" ASC NULLS LAST) INCLUDE ("id");
CREATE INDEX "ib_760a8e60a44aa6a3d21a6f661ca9012e38965a49d5024d8215515891630f" ON "public"."records" USING btree ("value" "pg_catalog"."int4_ops" ASC NULLS LAST) INCLUDE ("id", "payload");
